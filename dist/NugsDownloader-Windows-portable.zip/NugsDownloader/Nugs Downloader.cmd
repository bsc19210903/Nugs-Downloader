@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv || exit /b 1
)
for /f "usebackq delims=" %%H in (`".venv\Scripts\python.exe" -c "import hashlib; print(hashlib.sha256(open('requirements.txt','rb').read()).hexdigest())"`) do set REQ_HASH=%%H
set REQ_MARKER=.venv\requirements.sha256
set SAVED_REQ_HASH=
if exist "%REQ_MARKER%" set /p SAVED_REQ_HASH=<"%REQ_MARKER%"
if not "%REQ_HASH%"=="%SAVED_REQ_HASH%" (
  ".venv\Scripts\python.exe" -m pip install --upgrade pip || exit /b 1
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || exit /b 1
  echo %REQ_HASH%>"%REQ_MARKER%"
)
set NUGS_CONFIG_PATH=%LOCALAPPDATA%\NugsDownloader\config.json
set NUGS_CREDENTIALS_PATH=%LOCALAPPDATA%\NugsDownloader\nugs_credentials.enc
set NUGS_CREDENTIALS_KEY_PATH=%LOCALAPPDATA%\NugsDownloader\nugs_credentials.key
set NUGS_HISTORY_DB_PATH=%LOCALAPPDATA%\NugsDownloader\download_history.sqlite3
set NUGS_DEFAULT_OUT_PATH=%USERPROFILE%\Music\Nugs Downloader
if not exist "%LOCALAPPDATA%\NugsDownloader" mkdir "%LOCALAPPDATA%\NugsDownloader"
".venv\Scripts\python.exe" launcher.py
