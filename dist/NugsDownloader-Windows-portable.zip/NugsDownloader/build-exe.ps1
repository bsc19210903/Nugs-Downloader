$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (!(Test-Path ".venv\Scripts\python.exe")) {
  py -3 -m venv .venv
}
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
.\.venv\Scripts\pyinstaller.exe --noconfirm --clean --onefile --windowed --name "Nugs Downloader" --add-data "web;web" --add-data "main.py;." --add-data "server.py;." --add-data "nugs_credentials.py;." launcher.py
Write-Host "Built dist\Nugs Downloader.exe"
