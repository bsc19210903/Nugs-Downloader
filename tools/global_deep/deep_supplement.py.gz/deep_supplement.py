#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, os, re, shutil, subprocess, tempfile, time, traceback, zipfile
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
import requests
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, LineString, Polygon, MultiPoint, MultiLineString, MultiPolygon, GeometryCollection
from shapely.validation import make_valid
from lxml import etree
from pypdf import PdfReader

KML_NS='http://www.opengis.net/kml/2.2'; K=f'{{{KML_NS}}}'
UA='GlobalFisheriesDeepStatic/2026-08-28'

@dataclass
class SourceResult:
    id:str; region:str; country:str; title:str; category:str; publisher:str; source_url:str; method:str
    status:str='pending'; features:int=0; vertices:int=0; bytes_downloaded:int=0; sha256:str=''; retrieved_at:str=''
    warnings:list[str]=field(default_factory=list); errors:list[str]=field(default_factory=list); files:list[str]=field(default_factory=list)

VECTORS=[
('nafo_divisions','International Waters — Northwest Atlantic','NAFO Regulatory Area','NAFO Divisions','RFMO management areas','NAFO','https://www.nafo.int/Portals/0/GIS/Divisions.zip'),
('nafo_footprint','International Waters — Northwest Atlantic','NAFO Regulatory Area','NAFO Bottom Fishing Footprint','Bottom-fishing footprint','NAFO','https://www.nafo.int/Portals/0/GIS/Footprint_Projected.zip'),
('nafo_vme','International Waters — Northwest Atlantic','NAFO Regulatory Area','NAFO VME Closures','Vulnerable marine ecosystem closures','NAFO','https://www.nafo.int/Portals/0/GIS/NAFO_VME_closures_2022.zip'),
('nafo_seamounts','International Waters — Northwest Atlantic','NAFO Regulatory Area','NAFO Seamount Closures','Seamount closures','NAFO','https://www.nafo.int/Portals/0/GIS/Seamounts2022poly.zip'),
('neafc_midatlantic','International Waters — Northeast Atlantic','NEAFC Regulatory Area','NEAFC Mid-Atlantic VME Closures','Vulnerable marine ecosystem closures','NEAFC','https://www.neafc.org/system/files/mid-atlantic-vme-closures.zip'),
('neafc_hatton_rockall','International Waters — Northeast Atlantic','NEAFC Regulatory Area','NEAFC Hatton-Rockall VME Closures','Vulnerable marine ecosystem closures','NEAFC','https://www.neafc.org/system/files/hr_shape_files_2018.zip'),
('neafc_irminger','International Waters — Northeast Atlantic','NEAFC Regulatory Area','NEAFC Irminger Sea Closure','Fisheries closure','NEAFC','https://www.neafc.org/system/files/IrmingerSeaClosure-shapefiles.zip'),
('siofa_area','International Waters — Southern Indian Ocean','SIOFA Area','SIOFA Agreement Area','RFMO management area','SIOFA','https://siofa.org/sites/default/files/gis/SIOFA-Area.zip'),
('siofa_subareas','International Waters — Southern Indian Ocean','SIOFA Area','SIOFA Sub-Areas','RFMO management subareas','SIOFA','https://siofa.org/sites/default/files/gis/siofa_subarea_final.zip'),
('siofa_toothfish','International Waters — Southern Indian Ocean','SIOFA Area','SIOFA Patagonian Toothfish Management Areas','Toothfish management areas','SIOFA','https://siofa.org/sites/default/files/gis/TOP-Interim-Management-Areas.zip'),
('siofa_bfc','International Waters — Southern Indian Ocean','SIOFA Area','SIOFA Benthic Fishery Closures','Benthic fishery closures','SIOFA','https://siofa.org/sites/default/files/gis/SIOFA-BFC-CMM18.zip'),
('siofa_footprint','International Waters — Southern Indian Ocean','SIOFA Area','SIOFA Bottom Fishing Footprint 2023','Bottom-fishing footprint','SIOFA','https://siofa.org/sites/default/files/gis/SIOFA_bottom%20fishing_footprint-2023.zip'),
('sprfmo_bottom','International Waters — South Pacific','SPRFMO Area','SPRFMO Bottom-Fishing Management Areas','Bottom-fishing management areas','SPRFMO','https://www.sprfmo.int/assets/Fisheries/Conservation-and-Management-Measures/2019-CMMs/CMM03-2019Shapefiles-Apr2019.zip'),
('acma_wa','Asia / Pacific','Australia','ACMA Western Australia Submarine Cable Protection Zone','Submarine cable protection zone / nominal cable positions','Australian Communications and Media Authority','https://www.acma.gov.au/sites/default/files/2019-10/Submarine%20Telecommunications%20Cables%20WA%20Protection%20Zone%20Geographic%20Coordinates.ZIP'),
('acma_nsw','Asia / Pacific','Australia','ACMA New South Wales Submarine Cable Protection Zones','Submarine cable protection zones / nominal cable positions','Australian Communications and Media Authority','https://www.acma.gov.au/sites/default/files/2019-10/Submarine%20Telecommunications%20Cables%20NSW%20Protection%20Zones%20Geographic%20Coordinates.zip'),
('acma_sspz_2025','Asia / Pacific','Australia','ACMA Southern Sydney Protection Zone 2025 Variation','Permit/protection-zone variation','Australian Communications and Media Authority','https://www.acma.gov.au/sites/default/files/2025-05/Spatial%20data%20download%20proposed%20SSPZ%20variation.zip'),
('iotc_eez_highseas','International Waters — Indian Ocean','IOTC Area','IOTC EEZ and High-Seas Areas','EEZ/high-seas reference areas','IOTC Secretariat','https://iotc.org/sites/default/files/documents/2018/03/IOTC-2018-TCAC04-DATA05_-_EEZ_shapefile.zip'),
]

ARCGIS=[
('nz_commercial','Asia / Pacific','New Zealand','NZ Commercial Fishing Restrictions','Fishing restrictions','New Zealand MPI','https://maps.mpi.govt.nz/wss/service/arcgis1/guest/MARINE/MARINE_Restrictions_CommercialFishingRegulations/MapServer',r'prohibit|closed|closure|benthic|seamount|trawl|submarine|cable|pipeline|protected'),
('nz_lines','Asia / Pacific','New Zealand','NZ Commercial Fishing Restriction Lines','Fishing restriction boundaries','New Zealand MPI','https://maps.mpi.govt.nz/wss/service/arcgis1/guest/MARINE/MARINE_Restrictions_CommercialFishingRegulations_Polyline/MapServer',r'trawl|closed|closure|cable|pipeline|prohibit'),
('nz_customary','Asia / Pacific','New Zealand','NZ Customary Fishing Areas','Customary fisheries areas','New Zealand MPI','https://maps.mpi.govt.nz/wss/service/arcgis1/guest/MARINE/MARINE_RestrictionsCustomary/MapServer',r'mataitai|taiapure|custom|reserve|closure'),
('au_epbc','Asia / Pacific','Australia','Australian EPBC Cable and Interconnector Referrals','Environmental permit/referral footprints','Australian Government DCCEEW','https://gis.environment.gov.au/gispubmap/rest/services/ogc_services/EPBC_Referrals/MapServer',r'.*'),
('za_cables','Africa','South Africa','South Africa Submarine Telecommunications Cables','Submarine cable routes','South Africa DFFE','https://screening.environment.gov.za/server/rest/services/OC_MSP/3_02_NDIR_Infrastructure/MapServer',r'cable|telecom'),
('za_eia_cables','Africa','South Africa','South Africa EIA Submarine Cable Development Footprints','Environmental application and development footprints','South Africa DFFE','https://portal.environment.gov.za/server/rest/services/ScreeningMaps/Screening_Site/MapServer',r'EIA Application Site|EIA Application Development Footprint'),
]

PERMITS=[
{'jurisdiction':'Hong Kong','project':'SEA-H2X','permit':'EP-661/2025','url':'https://www.epd.gov.hk/eia/files/applications/en/pp_937/aep_6064/progress/action_180045/ep_661/EP_661_2025.html','status':'permitted alignment in Figure 1; as-built coordinate plans required after installation'},
{'jurisdiction':'Hong Kong','project':'Sihanoukville-Hong Kong','permit':'EP-657/2025','url':'https://www.epd.gov.hk/eia/files/applications/en/pp_928/aep_5950/progress/action_167227/ep6572025.htm','status':'permitted 35 km alignment; as-built coordinate plans required'},
{'jurisdiction':'Hong Kong','project':'ALC-HK Cable Bundle','permit':'EP-659/2025','url':'https://www.epd.gov.hk/eia/files/applications/en/pp_931/aep_5962/progress/action_169495/ep6592025.htm','status':'permitted 37 km alignment; figure-only route pending coordinate publication'},
{'jurisdiction':'Hong Kong','project':'CCE Hong Kong Bundle','permit':'EP-682/2026','url':'https://www.epd.gov.hk/eia/files/applications/en/pp_1013/aep_6394/progress/action_179996/EP_682_2026/EP_682_2026.htm','status':'permitted 35 km alignment; figure-only route pending coordinate publication'},
{'jurisdiction':'Spain','project':'MAREA','permit':'BOE-B-2017-40592','url':'https://www.boe.es/diario_boe/txt.php?id=BOE-B-2017-40592','status':'coastal concession; route coordinates not in public one-page notice'},
{'jurisdiction':'Malaysia','project':'SEA-ME-WE 6','permit':'NTM 245(T)/2025','url':'https://www.marine.gov.my/elementor-34322/','status':'installation notice; parser attempts route-coordinate extraction'},
{'jurisdiction':'Malaysia','project':'ALC','permit':'NTM 82(T)/2026','url':'https://www.marine.gov.my/elementor-34322/','status':'main-lay notice; parser attempts route-coordinate extraction'},
{'jurisdiction':'Malaysia','project':'SEA-H2X','permit':'NTM 57(T)/2025','url':'https://www.marine.gov.my/elementor-34322/','status':'route survey notice; parser attempts coordinate extraction'},
]

def now(): return datetime.now(timezone.utc).isoformat()
def sess():
 s=requests.Session(); s.headers.update({'User-Agent':UA}); return s

def dl(s,url,path,timeout=300):
 r=s.get(url,timeout=timeout,allow_redirects=True); r.raise_for_status(); path.write_bytes(r.content); return r

def normalize_gdf(gdf):
 if gdf.empty:return gdf
 if gdf.crs is None:
  b=gdf.total_bounds
  if -181<=b[0]<=181 and -91<=b[1]<=91 and -181<=b[2]<=181 and -91<=b[3]<=91:gdf=gdf.set_crs(4326)
  else: raise ValueError(f'missing CRS with implausible bounds {b}')
 gdf=gdf.to_crs(4326)
 gdf=gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty].copy()
 gdf['geometry']=gdf.geometry.apply(lambda g: make_valid(g) if not g.is_valid else g)
 return gdf.explode(index_parts=False,ignore_index=True)

def read_archive(path,tmp):
 out=[]
 d=tmp/path.stem; d.mkdir(parents=True,exist_ok=True)
 if zipfile.is_zipfile(path):
  with zipfile.ZipFile(path) as z:z.extractall(d)
 else: subprocess.run(['7z','x','-y',str(path),f'-o{d}'],check=True,stdout=subprocess.DEVNULL)
 for p in d.rglob('*'):
  if p.suffix.lower() in {'.shp','.gpkg','.geojson','.json','.kml'}:
   try:
    if p.suffix.lower()=='.kml': continue
    if p.suffix.lower()=='.gpkg':
     import pyogrio
     for lyr in pyogrio.list_layers(p)[:,0]: out.append((f'{p.name}:{lyr}',normalize_gdf(gpd.read_file(p,layer=lyr))))
    else: out.append((p.name,normalize_gdf(gpd.read_file(p))))
   except Exception: pass
 return [(n,g) for n,g in out if not g.empty]

def arcgis_layers(s,root,pattern):
 meta=s.get(root,params={'f':'json'},timeout=120).json(); rx=re.compile(pattern,re.I); out=[]
 for x in meta.get('layers',[]):
  name=str(x.get('name','')); lid=x.get('id')
  if lid is not None and rx.search(name): out.append((lid,name))
 return out

def arcgis_gdf(s,url,where='1=1'):
 meta=s.get(url,params={'f':'json'},timeout=120).json(); ids=s.get(url+'/query',params={'f':'json','where':where,'returnIdsOnly':'true'},timeout=180).json().get('objectIds') or []
 feats=[]; step=min(int(meta.get('maxRecordCount') or 1000),1000)
 for i in range(0,len(ids),step):
  q={'f':'geojson','objectIds':','.join(map(str,ids[i:i+step])),'outFields':'*','returnGeometry':'true','outSR':4326}
  j=s.get(url+'/query',params=q,timeout=300).json(); feats.extend(j.get('features') or [])
 if not ids:
  j=s.get(url+'/query',params={'f':'geojson','where':where,'outFields':'*','returnGeometry':'true','outSR':4326,'resultRecordCount':10000},timeout=300).json(); feats=j.get('features') or []
 return normalize_gdf(gpd.GeoDataFrame.from_features(feats,crs=4326)) if feats else gpd.GeoDataFrame(geometry=[],crs=4326)

def geom_vertices(g):
 if g.geom_type=='Point':return 1
 if g.geom_type in ('LineString','LinearRing'):return len(g.coords)
 if g.geom_type=='Polygon':return len(g.exterior.coords)+sum(len(r.coords) for r in g.interiors)
 if hasattr(g,'geoms'):return sum(geom_vertices(x) for x in g.geoms)
 return 0

def add(parent,tag,text=None,**attrs):
 e=etree.SubElement(parent,K+tag,**attrs)
 if text is not None:e.text=str(text)
 return e

def coords(seq):return ' '.join(f'{x:.7f},{y:.7f},0' for x,y,*_ in seq)
def add_geom(parent,g):
 t=g.geom_type
 if t=='Point': p=add(parent,'Point'); add(p,'coordinates',f'{g.x:.7f},{g.y:.7f},0')
 elif t=='LineString': p=add(parent,'LineString');add(p,'tessellate','1');add(p,'coordinates',coords(g.coords))
 elif t=='Polygon':
  p=add(parent,'Polygon');add(p,'tessellate','1');o=add(p,'outerBoundaryIs');r=add(o,'LinearRing');add(r,'coordinates',coords(g.exterior.coords))
  for ring in g.interiors:i=add(p,'innerBoundaryIs');rr=add(i,'LinearRing');add(rr,'coordinates',coords(ring.coords))
 elif t.startswith('Multi') or t=='GeometryCollection':
  m=add(parent,'MultiGeometry')
  for x in g.geoms:add_geom(m,x)
 else: raise ValueError(t)

def safe(v):
 if v is None:return ''
 if isinstance(v,float) and (math.isnan(v) or math.isinf(v)):return ''
 return str(v)[:5000]

def gdf_folder(src,gdfs,res):
 f=etree.Element(K+'Folder');add(f,'name',src['title']);add(f,'open','0')
 desc=f"Publisher: {src['publisher']}\nCategory: {src['category']}\nSource: {src['url']}\nRetrieved: {now()}"
 add(f,'description',desc); idx=0
 for layer,gdf in gdfs:
  lf=add(f,'Folder');add(lf,'name',layer);add(lf,'open','0')
  for _,row in gdf.iterrows():
   g=row.geometry
   if g is None or g.is_empty:continue
   idx+=1;pm=add(lf,'Placemark')
   name=''
   for key in row.index:
    if key!='geometry' and re.search(r'name|title|area|site|project|label|code',str(key),re.I) and safe(row[key]): name=safe(row[key]);break
   add(pm,'name',name or f"{src['title']} #{idx}")
   ed=add(pm,'ExtendedData')
   base={'snapshot_source_id':src['id'],'snapshot_publisher':src['publisher'],'snapshot_category':src['category'],'snapshot_source_url':src['url'],'snapshot_layer':layer,'snapshot_retrieved_at':now()}
   for k,v in list(base.items())+[(str(k),row[k]) for k in row.index if k!='geometry']:
    d=add(ed,'Data',name=re.sub(r'[^\w.:-]','_',str(k))[:150]);add(d,'value',safe(v))
   add_geom(pm,g);res.features+=1;res.vertices+=geom_vertices(g)
 return f

def parse_coord(s):
 s=s.strip().upper().replace('º','°').replace('’',"'").replace('′',"'").replace('″','"').replace('·','.')
 hemi=None
 m=re.search(r'([NSEW])',s)
 if m:hemi=m.group(1)
 nums=[float(x) for x in re.findall(r'\d+(?:\.\d+)?',s)]
 if not nums:return None
 val=nums[0]+(nums[1]/60 if len(nums)>1 else 0)+(nums[2]/3600 if len(nums)>2 else 0)
 if hemi in ('S','W'):val=-val
 return val


def dm(deg,minutes,hemi=None):
 val=float(deg)+float(minutes)/60.0
 if str(hemi or '').upper() in ('S','W'):val=-val
 return val

def ll(lon_deg,lon_min,lat_deg,lat_min,lon_hemi='E',lat_hemi='N'):
 return (dm(lon_deg,lon_min,lon_hemi),dm(lat_deg,lat_min,lat_hemi))

def singapore_authoritative_gdfs():
 """Exact coordinates transcribed from official Singapore MPA notices.

 Each chart fragment stays separate. This avoids drawing invented connections
 across chart boundaries or between legally distinct notices.
 """
 charted=[]
 def line(name,notice,chart,pts,status='charted submarine cable',authority='Maritime and Port Authority of Singapore'):
  charted.append({'name':name,'notice':notice,'chart':chart,'route_status':status,'geometry_authority':authority,'geometry':LineString(pts)})
 # NM 29/2025 — chart corrections for an existing submarine cable.
 line('Submarine cable chart correction — GSP1/SP1 west','MPA NM 29/2025','GSP1 / SP1',[
  ll(103,37.19,1,12.98),ll(103,36.89,1,12.27),ll(103,35.93,1,11.66),ll(103,34.68,1,11.53),ll(103,34.00,1,10.50)])
 line('Submarine cable chart correction — GSP1/SP1 central','MPA NM 29/2025','GSP1 / SP1',[
  ll(103,44.93,1,6.43),ll(103,45.10,1,7.04),ll(103,53.08,1,11.73),ll(103,57.64,1,13.56),ll(104,5.00,1,14.59),ll(104,8.10,1,14.31)])
 line('Submarine cable chart correction — GSP1/SP1 east','MPA NM 29/2025','GSP1 / SP1',[
  ll(104,38.17,1,18.53),ll(104,38.60,1,18.64),ll(104,40.30,1,18.90),ll(104,44.00,1,17.42),ll(104,48.89,1,15.63)])
 line('Submarine cable chart correction — Chart 501','MPA NM 29/2025','Chart 501',[
  ll(103,37.19,1,12.98),ll(103,36.89,1,12.27),ll(103,35.93,1,11.66),ll(103,34.68,1,11.53),ll(103,31.50,1,6.81),ll(103,31.53,1,6.58),ll(103,34.46,1,4.53),ll(103,38.79,1,1.79),ll(103,39.53,1,1.66),ll(103,40.10,1,1.80),ll(103,44.80,1,5.94),ll(103,45.10,1,7.04),ll(103,53.08,1,11.73),ll(103,55.05,1,12.52)])
 line('Submarine cable chart correction — Chart 500 west','MPA NM 29/2025','Chart 500',[
  ll(103,37.19,1,12.98),ll(103,36.89,1,12.27),ll(103,35.93,1,11.66),ll(103,34.68,1,11.53),ll(103,31.50,1,6.81),ll(103,31.53,1,6.58),ll(103,34.46,1,4.53),ll(103,35.21,1,4.05)])
 line('Submarine cable chart correction — Chart 500 east','MPA NM 29/2025','Chart 500',[
  ll(103,42.64,1,4.05),ll(103,44.61,1,5.79)])
 line('Submarine cable chart correction — Chart 503','MPA NM 29/2025','Chart 503',[
  ll(104,11.89,1,14.26),ll(104,15.46,1,14.27),ll(104,23.93,1,16.07),ll(104,25.13,1,15.87),ll(104,26.07,1,16.49),ll(104,26.86,1,16.49),ll(104,27.41,1,16.77),ll(104,32.71,1,17.55),ll(104,33.76,1,17.35),ll(104,38.17,1,18.53)])
 line('Submarine cable chart correction — Chart 502','MPA NM 29/2025','Chart 502',[
  ll(103,51.43,1,10.81),ll(103,53.08,1,11.73),ll(103,57.64,1,13.56),ll(104,5.00,1,14.59),ll(104,8.75,1,14.25),ll(104,15.46,1,14.27),ll(104,17.31,1,14.66)])
 # NM 74P/2025 — exact route positions for fibre-optic cable deployment.
 deployment=[{'name':'Batam–Jakarta fibre-optic cable deployment route','notice':'MPA NM 74P/2025','source_notice':'Pushidrosal Indonesian Notice 25/225P/2025','route_status':'deployment / preliminary route positions','geometry_authority':'MPA republication of Indonesian hydrographic notice','geometry':LineString([
  ll(104,8.32,1,10.02),ll(104,8.47,1,10.00),ll(104,9.39,1,12.90),ll(104,9.43,1,12.93),ll(104,17.35,1,12.96),ll(104,24.03,1,14.35),ll(104,28.24,1,16.60),ll(104,42.35,1,17.43),ll(104,43.24,1,17.89),ll(104,48.89,1,15.88)])}]
 # Admiralty NTM 4692/25, republished in the MPA monthly extract.
 line('South China Sea submarine cable — Chart 4039 route A','MPA Nov 2025 extract / Admiralty NTM 4692/25','Chart 4039',[
  ll(103,38.22,1,1.50),ll(103,35.60,1,2.96),ll(103,35.57,1,3.14),ll(103,33.37,1,4.47),ll(103,33.24,1,4.95),ll(103,31.20,1,6.12)],authority='UKHO/Indonesian hydrographic notice republished by MPA')
 line('South China Sea submarine cable — Chart 4039 route B','MPA Nov 2025 extract / Admiralty NTM 4692/25','Chart 4039',[
  ll(103,40.46,1,1.50),ll(103,42.60,1,3.10),ll(103,43.76,1,4.13),ll(103,45.98,1,6.21),ll(103,45.69,1,7.08),ll(103,46.37,1,7.69),ll(103,47.27,1,8.29),ll(103,48.82,1,8.85),ll(103,49.00,1,8.97)],authority='UKHO/Indonesian hydrographic notice republished by MPA')
 line('South China Sea submarine cable — Chart 4040','MPA Nov 2025 extract / Admiralty NTM 4692/25','Chart 4040',[
  ll(103,46.03,1,7.40),ll(103,46.33,1,7.65),ll(103,46.68,1,7.90),ll(103,47.12,1,8.19),ll(103,47.27,1,8.28),ll(103,48.83,1,8.86),ll(103,49.73,1,9.46),ll(103,50.73,1,9.94),ll(103,50.94,1,10.02),ll(103,51.06,1,10.09),ll(103,51.20,1,10.18),ll(103,51.36,1,10.35),ll(103,51.68,1,10.54),ll(103,51.73,1,10.56),ll(103,51.90,1,10.61)],authority='UKHO/Indonesian hydrographic notice republished by MPA')
 line('South China Sea submarine cable — Chart 4041','MPA Nov 2025 extract / Admiralty NTM 4692/25','Chart 4041',[
  ll(103,46.90,1,8.08),ll(103,48.85,1,8.87),ll(103,49.74,1,9.46),ll(103,50.96,1,10.03),ll(103,51.68,1,10.56),ll(103,52.12,1,10.64),ll(103,52.18,1,10.78),ll(103,53.56,1,10.92),ll(103,54.29,1,11.65),ll(103,55.09,1,11.42),ll(103,57.27,1,12.57),ll(103,57.52,1,12.46),ll(103,58.31,1,12.88),ll(104,2.03,1,13.35),ll(104,4.70,1,13.90)],authority='UKHO/Indonesian hydrographic notice republished by MPA')
 line('South China Sea submarine cable — Chart 4042','MPA Nov 2025 extract / Admiralty NTM 4692/25','Chart 4042',[
  ll(104,1.70,1,13.34),ll(104,2.33,1,13.35),ll(104,4.12,1,13.74),ll(104,4.28,1,13.88),ll(104,4.42,1,13.94),ll(104,6.47,1,13.30),ll(104,8.10,1,13.90),ll(104,8.23,1,14.15),ll(104,9.67,1,14.07),ll(104,9.85,1,14.36),ll(104,15.02,1,14.38),ll(104,16.64,1,14.80),ll(104,17.72,1,15.21),ll(104,17.96,1,15.00),ll(104,19.50,1,15.48)],authority='UKHO/Indonesian hydrographic notice republished by MPA')
 working=[
  {'name':'Submarine power cable installation working area','notice':'MPA PMN 38/2025','route_status':'temporary marine working area — not cable route','geometry_authority':'Maritime and Port Authority of Singapore','geometry':Polygon([ll(103,47.026,1,27.593),ll(103,47.380,1,27.817),ll(103,47.457,1,27.687),ll(103,47.108,1,27.461),ll(103,47.026,1,27.593)])},
  {'name':'Fibre-optic cable installation working area','notice':'MPA PMN 38/2026 (supersedes PMN 119/2025)','route_status':'temporary marine working area — not cable route','validity':'2026-03-06 through 2026-09-05','geometry_authority':'Maritime and Port Authority of Singapore','geometry':Polygon([ll(103,51.160,1,12.860),ll(103,51.122,1,12.936),ll(103,51.107,1,13.225),ll(103,51.155,1,13.332),ll(103,51.240,1,13.217),ll(103,51.167,1,13.127),ll(103,51.333,1,12.982),ll(103,51.160,1,12.860)])}
 ]
 return (
  normalize_gdf(gpd.GeoDataFrame(charted,crs=4326)),
  normalize_gdf(gpd.GeoDataFrame(deployment,crs=4326)),
  normalize_gdf(gpd.GeoDataFrame(working,crs=4326)),
 )

def malaysia_ntm_routes(s,tmp):
 routes=[]; notes=[]
 url='https://www.marine.gov.my/elementor-34322/'
 try:
  html=s.get(url,timeout=180).text
  hrefs=re.findall(r'href=["\']([^"\']+\.pdf)["\']',html,re.I)
  for h in hrefs:
   full=requests.compat.urljoin(url,h)
   if not re.search(r'cable|SEA-H2X|SEA-ME-WE|ALC|SJC',full,re.I):continue
   p=tmp/('ntm_'+hashlib.md5(full.encode()).hexdigest()+'.pdf')
   try:dl(s,full,p); text='\n'.join((page.extract_text() or '') for page in PdfReader(str(p)).pages)
   except Exception as e: notes.append({'url':full,'error':str(e)});continue
   pts=[]
   # Match latitude then longitude on same/adjacent line; supports decimal minutes and DMS.
   lines=[x.strip() for x in text.splitlines() if x.strip()]
   for i,line in enumerate(lines):
    candidates=[line]+lines[i:i+3]
    blob=' '.join(candidates)
    latm=re.search(r'(\d{1,2}\s*[° ]\s*\d{1,2}(?:\.\d+)?\s*[\' ]?(?:\d{1,2}(?:\.\d+)?\s*\")?\s*[NS])',blob,re.I)
    lonm=re.search(r'(\d{2,3}\s*[° ]\s*\d{1,2}(?:\.\d+)?\s*[\' ]?(?:\d{1,2}(?:\.\d+)?\s*\")?\s*[EW])',blob,re.I)
    if latm and lonm:
     lat=parse_coord(latm.group(1));lon=parse_coord(lonm.group(1))
     if lat is not None and lon is not None and (-90<=lat<=90 and -180<=lon<=180):
      if not pts or abs(pts[-1][0]-lon)>1e-8 or abs(pts[-1][1]-lat)>1e-8:pts.append((lon,lat))
   if len(pts)>=2: routes.append((Path(full).name,LineString(pts),full,text[:1000]))
   notes.append({'url':full,'points':len(pts),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 except Exception as e: notes.append({'url':url,'error':str(e)})
 return routes,notes

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path('dist-deep'));a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 s=sess();tmp=Path(tempfile.mkdtemp(prefix='deep-')); folders=[];results=[]
 for sid,region,country,title,cat,pub,url in VECTORS:
  res=SourceResult(sid,region,country,title,cat,pub,url,'archive');res.retrieved_at=now();src={'id':sid,'title':title,'category':cat,'publisher':pub,'url':url}
  try:
   p=tmp/(sid+'.zip');r=dl(s,url,p);res.bytes_downloaded=p.stat().st_size;res.sha256=hashlib.sha256(p.read_bytes()).hexdigest();gdfs=read_archive(p,tmp);res.files=[n for n,_ in gdfs]
   if not gdfs:raise RuntimeError('no readable vector layers')
   folders.append((region,gdf_folder(src,gdfs,res)));res.status='embedded'
  except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}',traceback.format_exc(limit=3)]
  results.append(res)
 # ArcGIS services
 for sid,region,country,title,cat,pub,root,pattern in ARCGIS:
  res=SourceResult(sid,region,country,title,cat,pub,root,'arcgis');res.retrieved_at=now();src={'id':sid,'title':title,'category':cat,'publisher':pub,'url':root};gdfs=[]
  try:
   for lid,name in arcgis_layers(s,root,pattern):
    g=arcgis_gdf(s,f'{root}/{lid}')
    if sid in {'au_epbc','za_eia_cables'} and not g.empty:
     cols=[c for c in g.columns if c!='geometry']; mask=pd.Series(False,index=g.index)
     for c in cols:mask=mask|g[c].astype(str).str.contains(r'submarine cable|subsea cable|undersea cable|offshore cable|telecommunication cable|fibre optic|fiber optic|interconnector',case=False,regex=True,na=False)
     g=g[mask]
    if not g.empty:gdfs.append((name,g))
   if not gdfs:raise RuntimeError('no matching public features')
   folders.append((region,gdf_folder(src,gdfs,res)));res.status='embedded';res.files=[n for n,_ in gdfs]
  except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}',traceback.format_exc(limit=3)]
  results.append(res)
 # ICCAT geopackage in RAR
 sid='iccat_gis';res=SourceResult(sid,'International Waters — Atlantic','ICCAT Area','ICCAT Convention, Subareas and Management Units','RFMO and stock-management areas','ICCAT','https://www.iccat.int/Documents/Gis/ICCAT_gis.rar','rar-gpkg');res.retrieved_at=now();src={'id':sid,'title':res.title,'category':res.category,'publisher':res.publisher,'url':res.source_url}
 try:
  p=tmp/'iccat.rar';dl(s,res.source_url,p);res.bytes_downloaded=p.stat().st_size;res.sha256=hashlib.sha256(p.read_bytes()).hexdigest();d=tmp/'iccat';d.mkdir();subprocess.run(['7z','x','-y',str(p),f'-o{d}'],check=True,stdout=subprocess.DEVNULL)
  gdfs=[]
  import pyogrio
  for gpkg in d.rglob('*.gpkg'):
   for lyr in pyogrio.list_layers(gpkg)[:,0]:
    if re.search(r'grid',str(lyr),re.I):continue
    try:g=normalize_gdf(gpd.read_file(gpkg,layer=lyr));gdfs.append((str(lyr),g))
    except Exception:pass
  if not gdfs:raise RuntimeError('no ICCAT layers')
  folders.append((res.region,gdf_folder(src,gdfs,res)));res.status='embedded';res.files=[n for n,_ in gdfs]
 except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}']
 results.append(res)
 # CCAMLR official data repository, selected operational spatial datasets
 sid='ccamlr';res=SourceResult(sid,'International Waters — Southern Ocean','CCAMLR Area','CCAMLR MPAs, Management Areas and Research Blocks','Southern Ocean fisheries management geometry','CCAMLR','https://github.com/ccamlr/data','official-github');res.retrieved_at=now();src={'id':sid,'title':res.title,'category':res.category,'publisher':res.publisher,'url':res.source_url}
 try:
  d=tmp/'ccamlr';subprocess.run(['git','clone','--depth','1','https://github.com/ccamlr/data.git',str(d)],check=True,stdout=subprocess.DEVNULL)
  gdfs=[]
  for subdir in ['mpa','asd','ssru','ssmu','rb','oma','mpapd']:
   base=d/'geographical_data'/subdir
   if not base.exists():continue
   candidates=list(base.glob('*.json'))+list(base.glob('*EPSG4326.shp'))
   for p in candidates[:2]:
    try:g=normalize_gdf(gpd.read_file(p));
    except Exception:continue
    if not g.empty:gdfs.append((f'{subdir}/{p.name}',g));break
  if not gdfs:raise RuntimeError('no CCAMLR layers')
  folders.append((res.region,gdf_folder(src,gdfs,res)));res.status='embedded';res.files=[n for n,_ in gdfs]
 except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}']
 results.append(res)
 # Singapore MPA exact chart corrections, route positions and working-area permits
 sg_sets=singapore_authoritative_gdfs()
 sg_specs=[
  ('sg_mpa_charted_cables','Singapore MPA Charted Submarine Cable Routes','Charted and corrected submarine cable positions','https://www.mpa.gov.sg/staticfile/CWP/assets/ntm/2025/NTM2925.pdf','Official notice coordinate tables',sg_sets[0]),
  ('sg_mpa_deployment_route','Singapore MPA Fibre-Optic Cable Deployment Route','Permit/deployment route position list','https://www.mpa.gov.sg/staticfile/CWP/assets/ntm/2025/NTM7425.pdf','Official notice coordinate table',sg_sets[1]),
  ('sg_mpa_working_areas','Singapore MPA Cable Installation Working Areas','Temporary cable-installation working polygons','https://www.mpa.gov.sg/docs/mpalibraries/circulars-and-notices/port-marine-circulars/pmc-38-of-2026.pdf','Official port marine notice coordinate tables',sg_sets[2]),
 ]
 for sid,title,cat,url,method,g in sg_specs:
  res=SourceResult(sid,'Asia / Pacific','Singapore',title,cat,'Maritime and Port Authority of Singapore',url,method);res.retrieved_at=now();src={'id':sid,'title':title,'category':cat,'publisher':res.publisher,'url':url}
  try:
   folders.append((res.region,gdf_folder(src,[('Official coordinate tables',g)],res)));res.status='embedded';res.files=['manual transcription verified against official coordinate table']
  except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}']
  results.append(res)

 # Malaysia notices-to-mariners exact route coordinate extraction
 sid='malaysia_ntm_rpl';res=SourceResult(sid,'Asia / Pacific','Malaysia','Malaysia Notice-to-Mariners Submarine Cable Route Positions','Permit/installation-notice route position lists','Malaysia Marine Department','https://www.marine.gov.my/elementor-34322/','permit-pdf-rpl');res.retrieved_at=now();src={'id':sid,'title':res.title,'category':res.category,'publisher':res.publisher,'url':res.source_url}
 try:
  routes,notes=malaysia_ntm_routes(s,tmp);(a.out/'malaysia_ntm_parse_ledger.json').write_text(json.dumps(notes,indent=2,ensure_ascii=False))
  if routes:
   rows=[{'name':n,'notice_url':u,'excerpt':ex,'geometry':g} for n,g,u,ex in routes];g=normalize_gdf(gpd.GeoDataFrame(rows,crs=4326));folders.append((res.region,gdf_folder(src,[('RPL-derived routes',g)],res)));res.status='embedded';res.files=[x[0] for x in routes]
  else:raise RuntimeError('no route position list could be parsed from linked notice PDFs')
 except Exception as e:res.status='failed';res.errors=[f'{type(e).__name__}: {e}']
 results.append(res)
 # Build static KML
 root=etree.Element(K+'kml',nsmap={None:KML_NS});doc=add(root,'Document');add(doc,'name','Global Fisheries & Submarine Cable Deep Supplement — Static');add(doc,'description','Fully embedded permit-derived cable geometry and international fisheries-management geometry. No NetworkLinks or runtime APIs.')
 order=['Asia / Pacific','Africa','International Waters — Atlantic','International Waters — Northwest Atlantic','International Waters — Northeast Atlantic','International Waters — Indian Ocean','International Waters — Southern Indian Ocean','International Waters — South Pacific','International Waters — Southern Ocean']
 for region in order:
  rf=add(doc,'Folder');add(rf,'name',region);add(rf,'open','0')
  for r,f in folders:
   if r==region:rf.append(f)
 kml=a.out/'global_deep_supplement.kml';etree.ElementTree(root).write(str(kml),encoding='UTF-8',xml_declaration=True,pretty_print=False)
 kmz=a.out/'global_deep_supplement.kmz'
 with zipfile.ZipFile(kmz,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.write(kml,'doc.kml')
 # validation
 tr=etree.parse(str(kml),etree.XMLParser(huge_tree=True));pms=tr.xpath(".//*[local-name()='Placemark']");nls=tr.xpath(".//*[local-name()='NetworkLink']");coords_els=tr.xpath(".//*[local-name()='coordinates']");bad=0;verts=0
 for e in coords_els:
  for t in re.split(r'\s+',e.text.strip() if e.text else ''):
   if not t:continue
   try:lon,lat=map(float,t.split(',')[:2]);bad+=0 if -180<=lon<=180 and -90<=lat<=90 else 1;verts+=1
   except:bad+=1
 val={'xml_parse_ok':True,'placemarks':len(pms),'networklinks':len(nls),'networklinks_zero':not nls,'coordinate_vertices':verts,'invalid_coordinate_tokens':bad,'coordinates_valid':bad==0,'kml_sha256':hashlib.sha256(kml.read_bytes()).hexdigest(),'kmz_sha256':hashlib.sha256(kmz.read_bytes()).hexdigest()}
 (a.out/'global_deep_supplement_validation.json').write_text(json.dumps(val,indent=2))
 ledger={'generated_at':now(),'summary':{'sources':len(results),'embedded':sum(x.status=='embedded' for x in results),'features':sum(x.features for x in results),'vertices':sum(x.vertices for x in results)},'validation':val,'sources':[asdict(x) for x in results],'permit_research_index':PERMITS}
 (a.out/'global_deep_supplement_ledger.json').write_text(json.dumps(ledger,indent=2,ensure_ascii=False))
 with (a.out/'global_deep_supplement_ledger.csv').open('w',newline='',encoding='utf-8') as fh:
  w=csv.DictWriter(fh,fieldnames=list(SourceResult.__dataclass_fields__));w.writeheader()
  for x in results:
   d=asdict(x)
   for k,v in d.items():
    if isinstance(v,(list,dict)):d[k]=json.dumps(v,ensure_ascii=False)
   w.writerow(d)
 (a.out/'global_deep_supplement_summary.txt').write_text(f"Sources embedded: {ledger['summary']['embedded']} / {len(results)}\nFeatures: {ledger['summary']['features']}\nVertices: {ledger['summary']['vertices']}\nNetworkLinks: {val['networklinks']}\n")
 print(json.dumps(ledger['summary'],indent=2));print(json.dumps(val,indent=2))

if __name__=='__main__':main()
